import { cn } from '@/lib/utils';
import { useScrollAnimation, useStaggerAnimation } from '@/hooks/useScrollAnimation';
import { GraduationCap, Calendar, BookOpen } from 'lucide-react';
import { educationConfig } from '@/config';
import { useLanguage } from '@/contexts/LanguageContext';

export function Education() {
  const { language } = useLanguage();
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation({ threshold: 0.3 });
  const { containerRef: listRef, visibleItems } = useStaggerAnimation(educationConfig.items.length, 150);

  const label = educationConfig.label[language];
  const heading = educationConfig.heading[language];
  const description = educationConfig.description[language];

  return (
    <section id="education" className="w-full py-24 lg:py-32 bg-exvia-subtle/30">
      <div className="container-large px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="max-w-3xl mb-16">
          <div
            className={cn(
              'transition-all duration-800 ease-out-quart',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            )}
          >
            <span className="text-xs font-geist-mono uppercase tracking-widest text-exvia-black/50">
              {label}
            </span>
          </div>

          <h2
            className={cn(
              'text-h2 font-semibold text-exvia-black mt-4 transition-all duration-800 ease-out-quart whitespace-pre-line',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '100ms' }}
          >
            {heading}
          </h2>

          <p
            className={cn(
              'mt-6 text-lg text-exvia-black/60 leading-relaxed transition-all duration-800 ease-out-quart',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '200ms' }}
          >
            {description}
          </p>
        </div>

        {/* Education Timeline */}
        <div ref={listRef} className="space-y-6">
          {educationConfig.items.map((edu, index) => (
            <div
              key={index}
              className={cn(
                'group relative bg-white rounded-xl p-6 lg:p-8 transition-all duration-700 ease-out-quart hover:shadow-lg',
                visibleItems[index] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              )}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start gap-4 lg:gap-6">
                {/* Icon */}
                <div className="flex-shrink-0 w-14 h-14 bg-exvia-black rounded-xl flex items-center justify-center group-hover:bg-exvia-black/80 transition-colors">
                  <GraduationCap className="w-7 h-7 text-white" />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-3 mb-2">
                    <h3 className="text-lg lg:text-xl font-semibold text-exvia-black">
                      {edu.degree[language]}
                    </h3>
                    <span className="px-3 py-1 bg-exvia-blue/10 rounded-full text-xs font-geist-mono text-exvia-blue flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {edu.period}
                    </span>
                  </div>

                  <p className="text-base text-exvia-black/70 font-medium">
                    {edu.institution}
                  </p>

                  <div className="flex items-start gap-2 mt-3 text-sm text-exvia-black/60">
                    <BookOpen className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    <span>{edu.thesis[language]}</span>
                  </div>
                </div>
              </div>

              {/* Timeline connector */}
              {index < educationConfig.items.length - 1 && (
                <div className="absolute left-[2.625rem] lg:left-[2.875rem] -bottom-6 w-px h-6 bg-exvia-border" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
