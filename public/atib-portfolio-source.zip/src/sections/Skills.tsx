import { useState } from 'react';
import { cn } from '@/lib/utils';
import { useScrollAnimation, useStaggerAnimation } from '@/hooks/useScrollAnimation';
import { useServiceParallax } from '@/hooks/useMouseParallax';
import * as Icons from 'lucide-react';
import { skillsConfig } from '@/config';
import { useLanguage } from '@/contexts/LanguageContext';

// Dynamically get icon component
function getIcon(iconName: string) {
  const IconComponent = (Icons as Record<string, React.ComponentType<{ className?: string }>>)[iconName];
  return IconComponent || Icons.Circle;
}

export function Skills() {
  const { language } = useLanguage();
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation({ threshold: 0.3 });
  const { containerRef: gridRef, visibleItems } = useStaggerAnimation(skillsConfig.categories.length, 120);
  const { containerRef: parallaxContainerRef, getTransform } = useServiceParallax();
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const label = skillsConfig.label[language];
  const heading = skillsConfig.heading[language];
  const description = skillsConfig.description[language];

  return (
    <section id="skills" className="w-full py-24 lg:py-32 bg-exvia-subtle/30">
      <div className="container-large px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="max-w-3xl mb-16">
          <div
            className={cn(
              'transition-all duration-800 ease-out-quart',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            )}
          >
            <span className="text-xs font-geist-mono uppercase tracking-widest text-exvia-black/50">
              {label}
            </span>
          </div>

          <h2
            className={cn(
              'text-h2 font-semibold text-exvia-black mt-4 transition-all duration-800 ease-out-quart whitespace-pre-line',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '100ms' }}
          >
            {heading}
          </h2>

          <p
            className={cn(
              'mt-6 text-lg text-exvia-black/60 leading-relaxed transition-all duration-800 ease-out-quart',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '200ms' }}
          >
            {description}
          </p>
        </div>

        {/* Skills Grid */}
        <div
          ref={(el) => {
            // Assign to both refs
            if (el) {
              (gridRef as React.MutableRefObject<HTMLDivElement | null>).current = el;
              (parallaxContainerRef as React.MutableRefObject<HTMLDivElement | null>).current = el;
            }
          }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {skillsConfig.categories.map((category, index) => {
            const IconComponent = getIcon(category.icon);
            return (
              <div
                key={index}
                className={cn(
                  'relative group cursor-pointer transition-all duration-700 ease-out-quart',
                  visibleItems[index] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                )}
                style={{ transitionDelay: `${index * 100}ms` }}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div className="relative overflow-hidden bg-white rounded-xl p-8 min-h-[280px] flex flex-col justify-between">
                  {/* Hover Image */}
                  <div
                    className={cn(
                      'absolute inset-0 transition-opacity duration-500',
                      hoveredIndex === index ? 'opacity-100' : 'opacity-0'
                    )}
                  >
                    <img
                      src={category.image}
                      alt={category.title[language]}
                      className="w-full h-full object-cover"
                      style={hoveredIndex === index ? getTransform(30, 3) : undefined}
                    />
                    <div className="absolute inset-0 bg-exvia-black/70" />
                  </div>

                  {/* Content */}
                  <div className="relative z-10">
                    <div className="flex items-center gap-3 mb-6">
                      <div className={cn(
                        'w-12 h-12 rounded-lg flex items-center justify-center transition-colors duration-300',
                        hoveredIndex === index ? 'bg-white/20' : 'bg-exvia-subtle'
                      )}>
                        <IconComponent className={cn(
                          'w-6 h-6 transition-colors duration-300',
                          hoveredIndex === index ? 'text-white' : 'text-exvia-black'
                        )} />
                      </div>
                      <h3 className={cn(
                        'text-xl font-semibold transition-colors duration-300',
                        hoveredIndex === index ? 'text-white' : 'text-exvia-black'
                      )}>
                        {category.title[language]}
                      </h3>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {category.skills.map((skill, skillIndex) => (
                        <span
                          key={skillIndex}
                          className={cn(
                            'px-3 py-1.5 rounded-full text-sm font-medium transition-colors duration-300',
                            hoveredIndex === index
                              ? 'bg-white/20 text-white'
                              : 'bg-exvia-subtle text-exvia-black/80'
                          )}
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Bottom decoration */}
                  <div className={cn(
                    'relative z-10 mt-6 text-xs font-geist-mono uppercase tracking-widest transition-colors duration-300',
                    hoveredIndex === index ? 'text-white/60' : 'text-exvia-black/40'
                  )}>
                    {category.skills.length} {language === 'zh' ? '项技能' : 'skills'}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
