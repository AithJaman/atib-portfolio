// Bilingual Site Configuration
// All content is provided in both English and Chinese

export type Language = 'en' | 'zh';

// ============================================================
// SITE CONFIG
// ============================================================
export interface SiteConfig {
  languages: Language[];
  defaultLanguage: Language;
  title: Record<Language, string>;
  description: Record<Language, string>;
}

export const siteConfig: SiteConfig = {
  languages: ['en', 'zh'],
  defaultLanguage: 'en',
  title: {
    en: 'Atib | Automation & Control Engineer',
    zh: '艾缇 | 自动化与控制工程师',
  },
  description: {
    en: 'Portfolio of MD Monjur A Alahi Atib - Automation & Control Engineer, Researcher, and Developer specializing in robust nonlinear control, PLC automation, and AI applications.',
    zh: 'MD Monjur A Alahi Atib（艾缇）的作品集——自动化与控制工程师、研究员和开发者，专攻鲁棒非线性控制、PLC自动化及AI应用。',
  },
};

// ============================================================
// NAVIGATION CONFIG
// ============================================================
export interface NavigationConfig {
  logo: Record<Language, string>;
  links: { label: Record<Language, string>; href: string }[];
  contactLabel: Record<Language, string>;
  contactHref: string;
}

export const navigationConfig: NavigationConfig = {
  logo: {
    en: 'Atib',
    zh: '艾缇',
  },
  links: [
    { label: { en: 'About', zh: '关于' }, href: '#about' },
    { label: { en: 'Skills', zh: '技能' }, href: '#skills' },
    { label: { en: 'Projects', zh: '项目' }, href: '#projects' },
    { label: { en: 'Publications', zh: '论文' }, href: '#publications' },
    { label: { en: 'Education', zh: '教育' }, href: '#education' },
  ],
  contactLabel: {
    en: 'Contact',
    zh: '联系',
  },
  contactHref: '#contact',
};

// ============================================================
// HERO CONFIG
// ============================================================
export interface HeroConfig {
  name: Record<Language, string>;
  roles: Record<Language, string[]>;
  backgroundImage: string;
  tagline: Record<Language, string>;
  subtitle: Record<Language, string>;
  badges: { icon: string; text: Record<Language, string> }[];
}

export const heroConfig: HeroConfig = {
  name: {
    en: 'ATIB',
    zh: '艾缇',
  },
  roles: {
    en: ['Control Engineer', 'Automation Specialist', 'Researcher', 'Developer'],
    zh: ['控制工程师', '自动化专家', '研究员', '开发者'],
  },
  backgroundImage: '/images/hero-bg.jpg',
  tagline: {
    en: "Automation & Control Engineer | Researcher",
    zh: "自动化与控制工程师 | 研究员",
  },
  subtitle: {
    en: "Master's in Control Engineering at Beihang University (BUAA). Specializing in robust nonlinear control, airship dynamics, PLC-based automation, and AI for e-commerce.",
    zh: "北京航空航天大学控制工程硕士。专攻鲁棒非线性控制、飞艇动力学、PLC自动化及电商AI应用。",
  },
  badges: [
    { icon: '🏆', text: { en: 'CSC Scholar (2023-2026)', zh: 'CSC奖学金 (2023-2026)' } },
    { icon: '📄', text: { en: '2 IFAC Papers', zh: '2篇IFAC论文' } },
    { icon: '🔧', text: { en: 'CSWP | Six Sigma', zh: 'CSWP | 六西格玛' } },
  ],
};

// ============================================================
// ABOUT CONFIG
// ============================================================
export interface AboutConfig {
  label: Record<Language, string>;
  description: Record<Language, string>;
  experienceValue: string;
  experienceLabel: Record<Language, string>;
  stats: { value: string; label: Record<Language, string> }[];
  images: { src: string; alt: Record<Language, string> }[];
}

export const aboutConfig: AboutConfig = {
  label: {
    en: 'About',
    zh: '关于',
  },
  description: {
    en: "Master's student in Control Engineering at Beihang University (BUAA). Published researcher with hands-on experience in MATLAB/Simulink, SolidWorks, and industrial control systems. Passionate about bridging the gap between theoretical control and practical automation.",
    zh: "北京航空航天大学控制工程硕士。已发表学术论文，精通MATLAB/Simulink、SolidWorks及工业控制系统。致力于弥合理论控制与实际自动化之间的差距。",
  },
  experienceValue: '6+',
  experienceLabel: {
    en: 'Years of\nResearch &\nEngineering',
    zh: '年研究\n与工程\n经验',
  },
  stats: [
    { value: '2', label: { en: 'IFAC\nPublications', zh: 'IFAC\n论文' } },
    { value: '5+', label: { en: 'Major\nProjects', zh: '主要\n项目' } },
    { value: '4', label: { en: 'Core\nSkill Areas', zh: '核心\n技能领域' } },
  ],
  images: [
    { src: '/images/about-1.jpg', alt: { en: 'PLC Programming', zh: 'PLC编程' } },
    { src: '/images/about-2.jpg', alt: { en: 'CAD Design', zh: 'CAD设计' } },
    { src: '/images/about-3.jpg', alt: { en: 'Airship Research', zh: '飞艇研究' } },
    { src: '/images/about-4.jpg', alt: { en: 'Conference Presentation', zh: '学术会议' } },
  ],
};

// ============================================================
// SKILLS CONFIG
// ============================================================
export interface SkillCategory {
  title: Record<Language, string>;
  icon: string;
  skills: string[];
  image: string;
}

export interface SkillsConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  categories: SkillCategory[];
}

export const skillsConfig: SkillsConfig = {
  label: {
    en: 'Technical Skills',
    zh: '技术技能',
  },
  heading: {
    en: 'Expertise &\nCapabilities',
    zh: '专业领域\n与能力',
  },
  description: {
    en: 'A multidisciplinary skill set spanning control theory, industrial automation, mechanical design, and artificial intelligence.',
    zh: '跨学科技能组合，涵盖控制理论、工业自动化、机械设计和人工智能。',
  },
  categories: [
    {
      title: { en: 'Control & Robotics', zh: '控制与机器人' },
      icon: 'Cpu',
      skills: ['MATLAB/Simulink', 'SMC / Backstepping', 'PID / LQR', 'Robust Control', 'Nonlinear Dynamics'],
      image: '/images/service-1.jpg',
    },
    {
      title: { en: 'PLC & Automation', zh: 'PLC与自动化' },
      icon: 'Settings',
      skills: ['Siemens LOGO! / S7-200', 'Ladder / FBD', 'SCADA / HMI', 'Industrial Wiring', 'Relay Logic'],
      image: '/images/service-2.jpg',
    },
    {
      title: { en: 'Design & Simulation', zh: '设计与仿真' },
      icon: 'Box',
      skills: ['SolidWorks (CSWP)', 'AutoCAD', 'FEA / CFD', 'MATLAB/Simulink', '3D Modeling'],
      image: '/images/service-3.jpg',
    },
    {
      title: { en: 'AI & Programming', zh: 'AI与编程' },
      icon: 'Brain',
      skills: ['Python / FastAPI', 'PyTorch / ResNet', 'DeepSeek API', 'Git / GitHub', 'Image Processing'],
      image: '/images/service-4.jpg',
    },
  ],
};

// ============================================================
// ACHIEVEMENTS CONFIG
// ============================================================
export interface Achievement {
  image: string;
  title: Record<Language, string>;
  subtitle: Record<Language, string>;
}

export interface AchievementsConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  items: Achievement[];
}

export const achievementsConfig: AchievementsConfig = {
  label: {
    en: 'Achievements',
    zh: '荣誉成就',
  },
  heading: {
    en: 'Awards &\nRecognition',
    zh: '奖项与\n荣誉',
  },
  description: {
    en: 'Key milestones and recognitions throughout my academic and professional journey.',
    zh: '学术与职业生涯中的重要里程碑与认可。',
  },
  items: [
    {
      image: '/images/about-1.jpg',
      title: { en: 'Chinese Government Scholarship', zh: '中国政府奖学金' },
      subtitle: { en: 'Fully Funded M.Sc. (2023-2026)', zh: '全额资助硕士 (2023-2026)' },
    },
    {
      image: '/images/about-4.jpg',
      title: { en: 'Best Paper Award', zh: '最佳论文奖' },
      subtitle: { en: 'IFAC Conference 2025', zh: 'IFAC会议 2025' },
    },
    {
      image: '/images/about-2.jpg',
      title: { en: 'Excellence Award', zh: '卓越奖' },
      subtitle: { en: 'Tsinghua IEDE Global Program', zh: '清华IEDE全球项目' },
    },
    {
      image: '/images/about-3.jpg',
      title: { en: '1st World Vocational Skills', zh: '首届世界职业院校' },
      subtitle: { en: 'Skills Competition Winner', zh: '技能大赛获奖者' },
    },
  ],
};

// ============================================================
// PORTFOLIO/PROJECTS CONFIG
// ============================================================
export interface ProjectItem {
  title: Record<Language, string>;
  category: Record<Language, string>;
  year: string;
  image: string;
  description: Record<Language, string>;
  result: Record<Language, string>;
  featured?: boolean;
}

export interface PortfolioConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  projects: ProjectItem[];
  cta: {
    label: Record<Language, string>;
    heading: Record<Language, string>;
    linkText: Record<Language, string>;
    linkHref: string;
  };
  viewAllLabel: Record<Language, string>;
}

export const portfolioConfig: PortfolioConfig = {
  label: {
    en: 'Featured Projects',
    zh: '代表性项目',
  },
  heading: {
    en: 'Selected\nWorks',
    zh: '精选\n作品',
  },
  description: {
    en: 'A collection of projects showcasing expertise in control systems, automation, AI integration, and sustainable energy solutions.',
    zh: '展示控制系统、自动化、AI集成和可持续能源解决方案专长的项目合集。',
  },
  projects: [
    {
      title: {
        en: 'Vector-Thrust Spherical Indoor Airship',
        zh: '矢量推力球形室内飞艇',
      },
      category: {
        en: 'Robust Control / MATLAB',
        zh: '鲁棒控制 / MATLAB',
      },
      year: '2025',
      image: '/images/portfolio-1.jpg',
      description: {
        en: "Developed a robust Sliding Mode Backstepping Controller for precise translational control under disturbances. 86% improvement in peak error vs. BSC, 79% faster recovery vs. SMC. Published in IFAC-PapersOnLine 2025.",
        zh: '设计鲁棒滑模反步控制器，在扰动下实现精确平动控制。峰值误差比BSC降低86%，恢复时间比SMC缩短79%。发表于IFAC-PapersOnLine 2025。',
      },
      result: {
        en: 'Published in IFAC-PapersOnLine 2025',
        zh: '发表于IFAC-PapersOnLine 2025',
      },
      featured: true,
    },
    {
      title: {
        en: 'PLC-Based Intelligent Home Automation',
        zh: '基于PLC的智能家居自动化',
      },
      category: {
        en: 'Siemens LOGO! / Automation',
        zh: 'Siemens LOGO! / 自动化',
      },
      year: '2023',
      image: '/images/portfolio-2.jpg',
      description: {
        en: 'Automated lighting, curtain, water pump, fire prevention & HVAC using Siemens LOGO! PLC. Reduced standby power by ~25%.',
        zh: '使用西门子LOGO! PLC自动化控制照明、窗帘、水泵、消防及暖通空调，待机功耗降低约25%。',
      },
      result: {
        en: 'Bachelor Thesis, CTGU 2023',
        zh: '本科毕业论文，三峡大学 2023',
      },
    },
    {
      title: {
        en: 'AI E-Commerce Content Automation',
        zh: 'AI电商内容自动化',
      },
      category: {
        en: 'DeepSeek / PyTorch / FastAPI',
        zh: 'DeepSeek / PyTorch / FastAPI',
      },
      year: '2024',
      image: '/images/portfolio-3.jpg',
      description: {
        en: 'Built system that classifies product images and generates captions/hashtags automatically using ResNet-18 and DeepSeek API. 97.8% accuracy.',
        zh: '使用ResNet-18和DeepSeek API搭建产品图像分类及自动生成描述与话题标签系统，准确率97.8%。',
      },
      result: {
        en: 'Reduces manual effort by 80%',
        zh: '减少80%人工工作量',
      },
    },
    {
      title: {
        en: '10 kW Residential Solar Power Plant',
        zh: '10kW户用太阳能电站',
      },
      category: {
        en: 'Renewable Energy / Design',
        zh: '可再生能源 / 设计',
      },
      year: '2023',
      image: '/images/portfolio-4.jpg',
      description: {
        en: 'Designed complete system with 24 panels, 15 batteries, saving >241,000 RMB over 25 years, reducing CO₂ by ~1.6 tons/kW/year.',
        zh: '设计24块光伏板、15块蓄电池的完整系统，25年节省超24.1万元，每年每千瓦减碳约1.6吨。',
      },
      result: {
        en: 'New Energy Project 2023',
        zh: '新能源项目 2023',
      },
    },
    {
      title: {
        en: 'Kitchen Fire Prevention System (PLC)',
        zh: '厨房防火系统 (PLC)',
      },
      category: {
        en: 'Safety / PLC / Relay Logic',
        zh: '安全 / PLC / 继电器逻辑',
      },
      year: '2020',
      image: '/images/portfolio-5.jpg',
      description: {
        en: 'Prevents 70% of unattended stove fires using timer circuits, alarm systems, and auto power cutoff with PLC relay logic.',
        zh: '采用定时电路、报警系统和PLC继电器逻辑自动断电，可预防70%无人看管炉灶火灾。',
      },
      result: {
        en: 'Science Fest Award 2020',
        zh: '科学节奖 2020',
      },
      featured: true,
    },
  ],
  cta: {
    label: {
      en: 'Let\'s Collaborate',
      zh: '合作咨询',
    },
    heading: {
      en: 'Have a project in mind?',
      zh: '有项目想法？',
    },
    linkText: {
      en: 'Get in Touch',
      zh: '联系我',
    },
    linkHref: '#contact',
  },
  viewAllLabel: {
    en: 'View All Projects',
    zh: '查看全部项目',
  },
};

// ============================================================
// PUBLICATIONS CONFIG
// ============================================================
export interface Publication {
  authors: string;
  title: string;
  journal: string;
  details: string;
  year: string;
}

export interface PublicationsConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  items: Publication[];
}

export const publicationsConfig: PublicationsConfig = {
  label: {
    en: 'Publications',
    zh: '学术论文',
  },
  heading: {
    en: 'Research\nPapers',
    zh: '研究\n论文',
  },
  description: {
    en: 'Peer-reviewed publications in leading control systems and automation conferences.',
    zh: '在领先控制系统与自动化会议上的同行评审论文。',
  },
  items: [
    {
      authors: 'M. A. A. Atib, H. Ambreen, M. Imran, W. Lei',
      title: 'Dual-Gas H₂/He Airship Design: Optimized Buoyancy and PID-Based Altitude Control',
      journal: 'IFAC-PapersOnLine',
      details: 'vol. 59, no. 20, pp. 2567-2572',
      year: '2025',
    },
    {
      authors: 'H. Ambreen, M. Imran, M. A. A. Atib, D. Tang',
      title: 'A Digital-Twin-Driven Modeling Approach for System Degradation and Remaining Useful Life Prediction',
      journal: 'IFAC-PapersOnLine',
      details: 'vol. 59, pp. 2177-2182',
      year: '2025',
    },
  ],
};

// ============================================================
// EDUCATION CONFIG
// ============================================================
export interface EducationItem {
  degree: Record<Language, string>;
  institution: string;
  period: string;
  thesis: Record<Language, string>;
}

export interface EducationConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  items: EducationItem[];
}

export const educationConfig: EducationConfig = {
  label: {
    en: 'Education',
    zh: '教育背景',
  },
  heading: {
    en: 'Academic\nBackground',
    zh: '学术\n背景',
  },
  description: {
    en: 'A strong academic foundation in control engineering, automation, and electrical technology across three countries.',
    zh: '在三个国家建立的控制系统工程、自动化和电气技术方面的扎实学术基础。',
  },
  items: [
    {
      degree: {
        en: 'M.Sc. in Control Engineering',
        zh: '控制工程硕士',
      },
      institution: 'Beihang University (BUAA)',
      period: '2023 - 2026',
      thesis: {
        en: 'Thesis: Robust translational control of vectored-thrust spherical indoor airship',
        zh: '论文：矢量推力球形室内飞艇鲁棒平动控制',
      },
    },
    {
      degree: {
        en: 'B.Eng. in Automation',
        zh: '自动化本科',
      },
      institution: 'China Three Gorges University (CTGU)',
      period: '2019 - 2023',
      thesis: {
        en: 'Thesis: PLC-based intelligent home automation system',
        zh: '论文：基于PLC的智能家居自动化系统',
      },
    },
    {
      degree: {
        en: 'Diploma in Electrical Technology',
        zh: '电气技术文凭',
      },
      institution: 'Akij Engineering Institute, Bangladesh',
      period: '2015 - 2019',
      thesis: {
        en: 'Focus: Industrial electrical systems and automation fundamentals',
        zh: '方向：工业电气系统与自动化基础',
      },
    },
  ],
};

// ============================================================
// CTA CONFIG
// ============================================================
export interface CTAConfig {
  tags: Record<Language, string[]>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  buttonText: Record<Language, string>;
  buttonHref: string;
  email: string;
  backgroundImage: string;
}

export const ctaConfig: CTAConfig = {
  tags: {
    en: ['Control Engineer', 'Automation Specialist', 'Researcher'],
    zh: ['控制工程师', '自动化专家', '研究员'],
  },
  heading: {
    en: "Let's build something\ntogether",
    zh: '让我们一起\n构建未来',
  },
  description: {
    en: "Open to collaborations in control systems, automation projects, and research partnerships. Whether you need a robust controller design or a complete automation solution, I'm ready to contribute.",
    zh: '欢迎控制系统、自动化项目和研究合作方面的合作。无论是鲁棒控制器设计还是完整的自动化解决方案，我都随时准备贡献。',
  },
  buttonText: {
    en: 'Send an Email',
    zh: '发送邮件',
  },
  buttonHref: 'mailto:atib@buaa.edu.cn',
  email: 'atib@buaa.edu.cn',
  backgroundImage: '/images/cta-bg.jpg',
};

// ============================================================
// FOOTER CONFIG
// ============================================================
export interface FooterConfig {
  logo: Record<Language, string>;
  description: Record<Language, string>;
  columns: {
    title: Record<Language, string>;
    links: { label: Record<Language, string>; href: string }[];
  }[];
  socialLinks: { iconName: string; href: string; label: string }[];
  copyright: Record<Language, string>;
  credit: Record<Language, string>;
}

export const footerConfig: FooterConfig = {
  logo: {
    en: 'Atib',
    zh: '艾缇',
  },
  description: {
    en: 'Automation & Control Engineer passionate about building intelligent systems that bridge theory and practice.',
    zh: '热衷于构建连接理论与实践的智能化系统的自动化与控制工程师。',
  },
  columns: [
    {
      title: {
        en: 'Navigation',
        zh: '导航',
      },
      links: [
        { label: { en: 'About', zh: '关于' }, href: '#about' },
        { label: { en: 'Skills', zh: '技能' }, href: '#skills' },
        { label: { en: 'Projects', zh: '项目' }, href: '#projects' },
        { label: { en: 'Publications', zh: '论文' }, href: '#publications' },
      ],
    },
    {
      title: {
        en: 'Resources',
        zh: '资源',
      },
      links: [
        { label: { en: 'Education', zh: '教育' }, href: '#education' },
        { label: { en: 'Contact', zh: '联系' }, href: '#contact' },
      ],
    },
  ],
  socialLinks: [
    { iconName: 'Linkedin', href: 'https://linkedin.com', label: 'LinkedIn' },
    { iconName: 'Github', href: 'https://github.com', label: 'GitHub' },
    { iconName: 'Mail', href: 'mailto:atib@buaa.edu.cn', label: 'Email' },
  ],
  copyright: {
    en: ' 2026 MD Monjur A Alahi Atib. All rights reserved.',
    zh: ' 2026 MD Monjur A Alahi Atib（艾缇）。保留所有权利。',
  },
  credit: {
    en: 'Built with React, TypeScript & Tailwind CSS',
    zh: '使用 React、TypeScript 和 Tailwind CSS 构建',
  },
};
