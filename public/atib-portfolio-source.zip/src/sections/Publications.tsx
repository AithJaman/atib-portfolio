import { cn } from '@/lib/utils';
import { useScrollAnimation, useStaggerAnimation } from '@/hooks/useScrollAnimation';
import { FileText, ExternalLink } from 'lucide-react';
import { publicationsConfig } from '@/config';
import { useLanguage } from '@/contexts/LanguageContext';

export function Publications() {
  const { language } = useLanguage();
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation({ threshold: 0.3 });
  const { containerRef: listRef, visibleItems } = useStaggerAnimation(publicationsConfig.items.length, 150);

  const label = publicationsConfig.label[language];
  const heading = publicationsConfig.heading[language];
  const description = publicationsConfig.description[language];

  return (
    <section id="publications" className="w-full py-24 lg:py-32 bg-white">
      <div className="container-large px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="max-w-3xl mb-16">
          <div
            className={cn(
              'transition-all duration-800 ease-out-quart',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            )}
          >
            <span className="text-xs font-geist-mono uppercase tracking-widest text-exvia-black/50">
              {label}
            </span>
          </div>

          <h2
            className={cn(
              'text-h2 font-semibold text-exvia-black mt-4 transition-all duration-800 ease-out-quart whitespace-pre-line',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '100ms' }}
          >
            {heading}
          </h2>

          <p
            className={cn(
              'mt-6 text-lg text-exvia-black/60 leading-relaxed transition-all duration-800 ease-out-quart',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '200ms' }}
          >
            {description}
          </p>
        </div>

        {/* Publications List */}
        <div ref={listRef} className="space-y-6">
          {publicationsConfig.items.map((pub, index) => (
            <div
              key={index}
              className={cn(
                'group relative bg-exvia-subtle/30 rounded-xl p-6 lg:p-8 transition-all duration-700 ease-out-quart hover:bg-exvia-subtle/50',
                visibleItems[index] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              )}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start gap-4 lg:gap-6">
                {/* Icon */}
                <div className="flex-shrink-0 w-12 h-12 bg-exvia-black rounded-lg flex items-center justify-center group-hover:bg-exvia-black/80 transition-colors">
                  <FileText className="w-6 h-6 text-white" />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg lg:text-xl font-semibold text-exvia-black leading-snug">
                    {pub.title}
                  </h3>
                  <p className="text-sm text-exvia-black/60 mt-2">
                    {pub.authors}
                  </p>
                  <div className="flex flex-wrap items-center gap-3 mt-3">
                    <span className="px-3 py-1 bg-exvia-black/5 rounded-full text-xs font-geist-mono text-exvia-black/70">
                      {pub.journal}
                    </span>
                    <span className="px-3 py-1 bg-exvia-black/5 rounded-full text-xs font-geist-mono text-exvia-black/70">
                      {pub.details}
                    </span>
                    <span className="px-3 py-1 bg-exvia-blue/10 rounded-full text-xs font-geist-mono text-exvia-blue">
                      {pub.year}
                    </span>
                  </div>
                </div>

                {/* Link */}
                <a
                  href="#"
                  className="flex-shrink-0 w-10 h-10 bg-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-2 group-hover:translate-x-0 shadow-sm"
                >
                  <ExternalLink className="w-4 h-4 text-exvia-black" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* IFAC Badge */}
        <div
          className={cn(
            'mt-12 flex items-center justify-center gap-4 transition-all duration-800 ease-out-quart',
            headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          )}
          style={{ transitionDelay: '600ms' }}
        >
          <div className="h-px flex-1 max-w-[100px] bg-exvia-border" />
          <span className="text-xs font-geist-mono uppercase tracking-widest text-exvia-black/40">
            IFAC - International Federation of Automatic Control
          </span>
          <div className="h-px flex-1 max-w-[100px] bg-exvia-border" />
        </div>
      </div>
    </section>
  );
}
