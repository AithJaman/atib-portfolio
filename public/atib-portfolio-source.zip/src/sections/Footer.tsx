import { cn } from '@/lib/utils';
import * as Icons from 'lucide-react';
import { footerConfig } from '@/config';
import { useLanguage } from '@/contexts/LanguageContext';

function getIcon(iconName: string) {
  const IconComponent = (Icons as Record<string, React.ComponentType<{ className?: string }>>)[iconName];
  return IconComponent || Icons.Globe;
}

export function Footer() {
  const { language } = useLanguage();

  const logo = footerConfig.logo[language];
  const description = footerConfig.description[language];
  const copyright = footerConfig.copyright[language];
  const credit = footerConfig.credit[language];

  return (
    <footer className="w-full bg-exvia-black text-white py-16 lg:py-20">
      <div className="container-large px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-5">
            <a href="#" className="inline-block">
              <span className="text-3xl font-bold tracking-tight">{logo}</span>
            </a>
            <p className="mt-4 text-white/60 max-w-sm leading-relaxed">
              {description}
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-3 mt-6">
              {footerConfig.socialLinks.map((link, index) => {
                const IconComponent = getIcon(link.iconName);
                return (
                  <a
                    key={index}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={link.label}
                    className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
                  >
                    <IconComponent className="w-4 h-4 text-white/80" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Link Columns */}
          {footerConfig.columns.map((column, colIndex) => (
            <div key={colIndex} className="lg:col-span-3 lg:col-start-7">
              <h4 className="text-sm font-geist-mono uppercase tracking-widest text-white/40 mb-4">
                {column.title[language]}
              </h4>
              <ul className="space-y-3">
                {column.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault();
                        const element = document.querySelector(link.href);
                        if (element) {
                          element.scrollIntoView({ behavior: 'smooth' });
                        }
                      }}
                      className="text-white/70 hover:text-white transition-colors"
                    >
                      {link.label[language]}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Contact Info */}
          <div className="lg:col-span-2">
            <h4 className="text-sm font-geist-mono uppercase tracking-widest text-white/40 mb-4">
              {language === 'zh' ? '联系方式' : 'Contact'}
            </h4>
            <div className="space-y-3 text-white/70">
              <p className="flex items-center gap-2">
                <Icons.MapPin className="w-4 h-4 text-white/40" />
                Beijing, China
              </p>
              <a
                href="mailto:atib@buaa.edu.cn"
                className="flex items-center gap-2 hover:text-white transition-colors"
              >
                <Icons.Mail className="w-4 h-4 text-white/40" />
                atib@buaa.edu.cn
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-white/10 my-12" />

        {/* Bottom Row */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-white/40">
          <p>{copyright}</p>
          <p>{credit}</p>
        </div>
      </div>
    </footer>
  );
}
