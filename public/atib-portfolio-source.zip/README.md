# Atib Portfolio - Bilingual Engineering Portfolio

A professional bilingual (English/Chinese) portfolio website for Automation & Control Engineers. Built with React + TypeScript + Tailwind CSS.

## Quick Links

- **Live Demo**: [https://akmqik5eepmpy.ok.kimi.link](https://akmqik5eepmpy.ok.kimi.link)
- **Stack**: React 19 + TypeScript + Vite + Tailwind CSS + shadcn/ui
- **Template**: exvia-style

---

## Step-by-Step Guide: Edit & Auto-Deploy

### Step 1: Create a GitHub Account

1. Go to [github.com](https://github.com)
2. Click **"Sign up"** (top right)
3. Enter your email, create a password
4. Follow the setup wizard
5. **Verify your email** (check your inbox)

### Step 2: Create a New Repository

1. Click the **"+"** button (top right) → **"New repository"**
2. Repository name: `atib-portfolio`
3. Set to **Public** (required for free hosting)
4. Click **"Create repository"**
5. Leave the page open - you'll need it for Step 3

### Step 3: Upload the Source Code

**Option A: Upload ZIP (Easiest)**
1. Download the `atib-portfolio-source.zip` file
2. Extract (unzip) it on your computer
3. Go back to your GitHub repository page
4. Click **"uploading an existing file"** link
5. Drag ALL files and folders from the extracted folder
6. Add a commit message: `Initial upload`
7. Click **"Commit changes"**

**Option B: Use Git (If you know Git)**
```bash
git init
git add .
git commit -m "Initial upload"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/atib-portfolio.git
git push -u origin main
```

### Step 4: Enable GitHub Pages

1. On your repository page, click **"Settings"** (top menu)
2. Scroll down the left sidebar → click **"Pages"**
3. Under **"Source"**, select: **"GitHub Actions"**
4. That's it! The workflow file is already in `.github/workflows/deploy.yml`

### Step 5: Trigger First Deploy

1. Go back to your repository's main page
2. Click the **"Actions"** tab (top menu)
3. You should see a workflow running (or waiting)
4. If it's not running, click **"Run workflow"** → **"Run workflow"**
5. Wait 2-3 minutes for the build to complete
6. Go back to **Settings → Pages**
7. Your live URL will appear: `https://YOUR_USERNAME.github.io/atib-portfolio`

---

## How to Edit Content

### Editing in GitHub (No Software Needed)

1. Go to your repository on GitHub
2. Navigate to `src/config.ts`
3. Click the **pencil icon** (top right) to edit
4. Make your changes
5. Scroll down → add commit message → click **"Commit changes"**
6. GitHub Actions will **automatically rebuild and redeploy** in 2-3 minutes
7. Refresh your live website to see changes

### What You Can Edit in `config.ts`

#### 1. Personal Info
```typescript
// Line ~16 - Your name
name: {
  en: 'ATIB',
  zh: '艾缇',
}

// Line ~27 - Your tagline
tagline: {
  en: 'Your new English tagline',
  zh: '你的新中文标语',
}

// Line ~31 - Your subtitle description
subtitle: {
  en: 'Your new description...',
  zh: '你的新简介...',
}
```

#### 2. Paper Links
Find the **Publications** section and change:
```typescript
// Add real links to your papers
{
  authors: 'M. A. A. Atib, H. Ambreen, M. Imran, W. Lei',
  title: 'Your Paper Title',
  journal: 'IFAC-PapersOnLine',
  details: 'vol. 59, no. 20, pp. 2567-2572',
  year: '2025',
  // ADD THIS LINE:
  link: 'https://www.sciencedirect.com/science/article/your-paper-url'
}
```

#### 3. Add New Projects
```typescript
{
  title: {
    en: 'Your New Project',
    zh: '你的新项目',
  },
  category: {
    en: 'Category / Tools',
    zh: '类别 / 工具',
  },
  year: '2025',
  image: '/images/portfolio-6.jpg', // Add image to public/images/
  description: {
    en: 'Project description in English...',
    zh: '项目中文描述...',
  },
  result: {
    en: 'Key result or achievement',
    zh: '关键成果',
  },
}
```

#### 4. Add New Achievements
```typescript
{
  image: '/images/award5.jpg', // Add image to public/images/
  title: { en: 'Award Name', zh: '奖项名称' },
  subtitle: { en: 'Details', zh: '详情' },
}
```

#### 5. Add New Education
```typescript
{
  degree: {
    en: 'Your Degree',
    zh: '学位名称',
  },
  institution: 'University Name',
  period: '2020 - 2024',
  thesis: {
    en: 'Thesis title in English',
    zh: '论文中文标题',
  },
}
```

#### 6. Change Contact Info
```typescript
email: 'your-new-email@example.com',
buttonHref: 'mailto:your-new-email@example.com',
```

### Adding Your Own Photos

1. Go to your repository on GitHub
2. Click `public/images/`
3. Click **"Add file"** → **"Upload files"**
4. Upload your photo (JPG or PNG)
5. Note the filename (e.g., `my-photo.jpg`)
6. Edit `src/config.ts` and update the image path:
```typescript
image: '/images/my-photo.jpg'
```

### Supported Image Sizes

| Image | Recommended Size | Usage |
|-------|-----------------|-------|
| Profile photo | 400x400px (1:1) | About section grid |
| Project images | 1200x900px (4:3) | Portfolio cards |
| Hero background | 1920x1080px (16:9) | Main banner |
| Achievement photos | 800x600px (4:3) | Award cards |

---

## File Structure

```
atib-portfolio/
  src/
    config.ts           ← EDIT THIS FILE for all content
    contexts/
      LanguageContext.tsx  ← Language switching logic
    components/
      Navigation.tsx    ← Navbar with language toggle
      AnimatedButton.tsx
      PageOverlay.tsx
    sections/
      Hero.tsx          ← Hero section
      About.tsx         ← About section
      Skills.tsx        ← Skills section
      Achievements.tsx  ← Achievements section
      Portfolio.tsx     ← Projects section
      Publications.tsx  ← Papers section
      Education.tsx     ← Education section
      CTA.tsx           ← Contact section
      Footer.tsx        ← Footer section
    pages/
      Home.tsx          ← Main page layout
    App.tsx             ← App router
    main.tsx            ← Entry point
    index.css           ← Global styles
  public/
    images/             ← All your photos go here
  .github/
    workflows/
      deploy.yml        ← Auto-deploy to GitHub Pages
  package.json
  vite.config.ts
  tailwind.config.js
  tsconfig.json
  README.md
```

---

## Local Development (Optional)

If you want to edit and preview locally before pushing:

### Prerequisites
- Install [Node.js](https://nodejs.org) (v20 or later)
- Install [Git](https://git-scm.com) (optional)

### Setup
```bash
# Clone your repository
git clone https://github.com/YOUR_USERNAME/atib-portfolio.git
cd atib-portfolio

# Install dependencies
npm install

# Start development server
npm run dev

# Open browser to: http://localhost:3000
```

### Build for production
```bash
npm run build
```

The built files will be in the `dist/` folder.

---

## Language Switching

The website supports **English (EN)** and **Chinese (中文)**.

- Toggle is in the top-right corner of the navbar
- All content is defined in both languages in `src/config.ts`
- Format: `{ en: 'English text', zh: '中文文本' }`

To add content in only one language, use the same text for both.

---

## Custom Domain (Optional)

You can use your own domain (e.g., `atib-portfolio.com`):

1. Buy a domain from [Namecheap](https://namecheap.com), [GoDaddy](https://godaddy.com), or [Alibaba Cloud](https://alibabacloud.com) (for China)
2. Go to **GitHub repository → Settings → Pages**
3. Under **"Custom domain"**, enter your domain
4. Add a CNAME record in your domain provider pointing to `YOUR_USERNAME.github.io`
5. GitHub will automatically create an SSL certificate (HTTPS)

---

## Troubleshooting

### Website not updating after edit?
- Go to **Actions** tab → check if the workflow is running
- If it failed, click on it to see the error message
- Make sure you committed the changes to the `main` branch

### Images not showing?
- Make sure images are in `public/images/` folder (not `src/`)
- Check the filename matches exactly (case-sensitive)
- Only use letters, numbers, hyphens, underscores in filenames

### Changes not reflecting?
- Clear browser cache (Ctrl+Shift+R or Cmd+Shift+R)
- Wait 2-3 minutes for GitHub Actions to finish
- Check the Actions tab for any build errors

### Website shows 404?
- Make sure GitHub Pages is enabled in Settings
- Repository must be **Public**
- Check that the deploy workflow ran successfully

---

## Credits

- **Template**: exvia-style
- **Built by**: Kimi AI (Moonshot AI)
- **Stack**: React + TypeScript + Vite + Tailwind CSS + shadcn/ui
- **Icons**: Lucide React
- **Font**: Geist

---

## License

This is your personal portfolio. Feel free to use, modify, and share.
