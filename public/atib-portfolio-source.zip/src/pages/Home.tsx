import { Navigation } from '@/components/Navigation';
import { PageOverlay } from '@/components/PageOverlay';
import { Hero } from '@/sections/Hero';
import { About } from '@/sections/About';
import { Skills } from '@/sections/Skills';
import { Achievements } from '@/sections/Achievements';
import { Portfolio } from '@/sections/Portfolio';
import { Publications } from '@/sections/Publications';
import { Education } from '@/sections/Education';
import { CTA } from '@/sections/CTA';
import { Footer } from '@/sections/Footer';
import { usePageLoad } from '@/hooks/usePageLoad';
import { useLanguage } from '@/contexts/LanguageContext';
import { siteConfig } from '@/config';

export default function Home() {
  const { showOverlay } = usePageLoad(500);
  const { language } = useLanguage();

  // Update page title based on language
  const title = siteConfig.title[language];
  document.title = title;

  return (
    <div className="min-h-screen bg-white">
      {/* Page Load Overlay */}
      <PageOverlay isVisible={showOverlay} title={title} />

      {/* Navigation */}
      <Navigation />

      {/* Main Content */}
      <main>
        <Hero />
        <About />
        <Skills />
        <Achievements />
        <Portfolio />
        <Publications />
        <Education />
        <CTA />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
