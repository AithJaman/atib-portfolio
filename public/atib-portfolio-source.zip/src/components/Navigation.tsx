import { useState, useEffect, type MouseEvent } from 'react';
import { cn } from '@/lib/utils';
import { AnimatedButton } from './AnimatedButton';
import { navigationConfig } from '@/config';
import { useLanguage } from '@/contexts/LanguageContext';

export function Navigation() {
  const { language, setLanguage, t } = useLanguage();

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 1800);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <>
      <nav
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-out-circ',
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4',
          isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm' : 'bg-transparent'
        )}
      >
        <div className="w-full px-6 lg:px-12 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a href="#" className="flex items-center">
              <span className={cn(
                "text-2xl font-semibold tracking-tight transition-colors duration-500",
                isScrolled ? "text-exvia-black" : "text-white"
              )}>
                {navigationConfig.logo[language]}
              </span>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-10">
              {navigationConfig.links.map((link) => (
                <a
                  key={link.label.en}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={cn(
                    "text-base transition-colors duration-500 relative group",
                    isScrolled ? "text-exvia-black/80 hover:text-exvia-black" : "text-white/90 hover:text-white"
                  )}
                >
                  {link.label[language]}
                  <span className={cn(
                    "absolute -bottom-1 left-0 w-0 h-px transition-all duration-300 group-hover:w-full",
                    isScrolled ? "bg-exvia-black" : "bg-white"
                  )} />
                </a>
              ))}
            </div>

            {/* Right Side: Language Toggle + Contact */}
            <div className="hidden lg:flex items-center gap-4">
              {/* Language Toggle */}
              <div className={cn(
                "flex items-center rounded-full p-1 transition-colors duration-500",
                isScrolled ? "bg-exvia-subtle" : "bg-white/10"
              )}>
                <button
                  onClick={() => setLanguage('en')}
                  className={cn(
                    "px-3 py-1 text-sm font-medium rounded-full transition-all duration-300",
                    language === 'en'
                      ? (isScrolled ? "bg-white text-exvia-black shadow-sm" : "bg-white text-exvia-black")
                      : (isScrolled ? "text-exvia-black/50 hover:text-exvia-black" : "text-white/60 hover:text-white")
                  )}
                >
                  EN
                </button>
                <button
                  onClick={() => setLanguage('zh')}
                  className={cn(
                    "px-3 py-1 text-sm font-medium rounded-full transition-all duration-300",
                    language === 'zh'
                      ? (isScrolled ? "bg-white text-exvia-black shadow-sm" : "bg-white text-exvia-black")
                      : (isScrolled ? "text-exvia-black/50 hover:text-exvia-black" : "text-white/60 hover:text-white")
                  )}
                >
                  中文
                </button>
              </div>

              {/* Contact Button */}
              <AnimatedButton
                href={navigationConfig.contactHref}
                variant={isScrolled ? "primary" : "outline-white"}
                size="md"
              >
                {navigationConfig.contactLabel[language]}
              </AnimatedButton>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden relative w-8 h-6 flex flex-col justify-between"
              aria-label="Toggle menu"
            >
              <span
                className={cn(
                  'w-full h-0.5 transition-all duration-500 ease-out-quad origin-center',
                  isScrolled ? 'bg-exvia-black' : 'bg-white',
                  isMenuOpen && 'translate-y-[10px] rotate-[-45deg]'
                )}
              />
              <span
                className={cn(
                  'w-full h-0.5 transition-all duration-300 ease-out-quad',
                  isScrolled ? 'bg-exvia-black' : 'bg-white',
                  isMenuOpen && 'scale-0 opacity-0'
                )}
              />
              <span
                className={cn(
                  'w-full h-0.5 transition-all duration-500 ease-out-quad origin-center',
                  isScrolled ? 'bg-exvia-black' : 'bg-white',
                  isMenuOpen && '-translate-y-[10px] rotate-[45deg]'
                )}
              />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div
        className={cn(
          'fixed inset-0 z-40 bg-white transition-all duration-500 ease-out-cubic lg:hidden',
          isMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'
        )}
      >
        <div className="flex flex-col items-center justify-center h-full gap-8">
          {/* Language Toggle - Mobile */}
          <div className="flex items-center rounded-full p-1 bg-exvia-subtle mb-4">
            <button
              onClick={() => setLanguage('en')}
              className={cn(
                "px-4 py-2 text-sm font-medium rounded-full transition-all duration-300",
                language === 'en' ? "bg-white text-exvia-black shadow-sm" : "text-exvia-black/50"
              )}
            >
              English
            </button>
            <button
              onClick={() => setLanguage('zh')}
              className={cn(
                "px-4 py-2 text-sm font-medium rounded-full transition-all duration-300",
                language === 'zh' ? "bg-white text-exvia-black shadow-sm" : "text-exvia-black/50"
              )}
            >
              中文
            </button>
          </div>

          {navigationConfig.links.map((link, index) => (
            <a
              key={link.label.en}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className={cn(
                'text-3xl font-semibold text-exvia-black transition-all duration-500 ease-out-quart',
                isMenuOpen
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              )}
              style={{ transitionDelay: isMenuOpen ? `${index * 100}ms` : '0ms' }}
            >
              {link.label[language]}
            </a>
          ))}
          <AnimatedButton
            href={navigationConfig.contactHref}
            variant="primary"
            size="lg"
            className={cn(
              'mt-4 transition-all duration-500 ease-out-quart',
              isMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            )}
            style={{ transitionDelay: isMenuOpen ? '400ms' : '0ms' }}
          >
            {navigationConfig.contactLabel[language]}
          </AnimatedButton>
        </div>
      </div>
    </>
  );
}
