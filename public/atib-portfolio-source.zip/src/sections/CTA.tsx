import { cn } from '@/lib/utils';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { ctaConfig } from '@/config';
import { useLanguage } from '@/contexts/LanguageContext';
import { AnimatedButton } from '@/components/AnimatedButton';
import { Mail, ArrowUpRight } from 'lucide-react';

export function CTA() {
  const { language } = useLanguage();
  const { ref: sectionRef, isVisible } = useScrollAnimation({ threshold: 0.3 });

  const tags = ctaConfig.tags[language];
  const heading = ctaConfig.heading[language];
  const description = ctaConfig.description[language];
  const buttonText = ctaConfig.buttonText[language];

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative w-full py-32 lg:py-40 overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={ctaConfig.backgroundImage}
          alt="CTA Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-exvia-black/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 container-large px-6 lg:px-12">
        <div className="max-w-3xl mx-auto text-center">
          {/* Tags */}
          <div
            className={cn(
              'flex flex-wrap justify-center gap-2 mb-8 transition-all duration-800 ease-out-quart',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            )}
          >
            {tags.map((tag, index) => (
              <span
                key={index}
                className="px-4 py-2 bg-white/10 rounded-full text-sm text-white/80 backdrop-blur-sm"
              >
                {tag}
              </span>
            ))}
          </div>

          {/* Heading */}
          <h2
            className={cn(
              'text-h2 font-semibold text-white whitespace-pre-line transition-all duration-800 ease-out-quart',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '100ms' }}
          >
            {heading}
          </h2>

          {/* Description */}
          <p
            className={cn(
              'mt-6 text-lg text-white/70 leading-relaxed transition-all duration-800 ease-out-quart',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '200ms' }}
          >
            {description}
          </p>

          {/* Email + Button */}
          <div
            className={cn(
              'mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 transition-all duration-800 ease-out-quart',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '300ms' }}
          >
            <AnimatedButton href={ctaConfig.buttonHref} variant="primary-white" size="lg">
              <Mail className="w-4 h-4 mr-2" />
              {buttonText}
            </AnimatedButton>

            <a
              href={`mailto:${ctaConfig.email}`}
              className="flex items-center gap-2 text-white/70 hover:text-white transition-colors group"
            >
              <span className="text-sm">{ctaConfig.email}</span>
              <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-1/2 left-8 -translate-y-1/2 w-px h-40 bg-white/10" />
      <div className="absolute top-1/2 right-8 -translate-y-1/2 w-px h-40 bg-white/10" />
    </section>
  );
}
