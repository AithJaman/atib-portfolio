import { useEffect, useState, useRef, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { heroConfig } from '@/config';
import { useLanguage } from '@/contexts/LanguageContext';
import { MapPin, Mail, GraduationCap } from 'lucide-react';

const boxSize = 450;
const halfBox = boxSize / 2;

export function Hero() {
  const { language, t } = useLanguage();
  const [isLoaded, setIsLoaded] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLElement>) => {
    const section = e.currentTarget;
    const rect = section.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    section.style.setProperty('--mouse-x', `${x - halfBox}px`);
    section.style.setProperty('--mouse-y', `${y - halfBox}px`);
  }, []);

  const roles = heroConfig.roles[language];
  const name = heroConfig.name[language];

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative w-full min-h-screen overflow-hidden bg-neutral-900 cursor-none"
      onMouseMove={handleMouseMove}
      style={{ '--mouse-x': 'calc(42vw - 200px)', '--mouse-y': 'calc(28vh - 200px)' } as React.CSSProperties}
    >
      {/* Background Image with Blur */}
      <div
        className={cn(
          'absolute inset-0 transition-opacity duration-[1800ms]',
          isLoaded && imageLoaded ? 'opacity-100' : 'opacity-0'
        )}
      >
        <img
          src={heroConfig.backgroundImage}
          alt="Hero Background"
          className="absolute inset-0 w-full h-full object-cover"
          style={{ filter: 'blur(15px) brightness(0.7)' }}
          onLoad={() => setImageLoaded(true)}
        />
      </div>

      {/* Sharp Image Container */}
      <div
        className={cn(
          'absolute top-0 left-0 overflow-hidden pointer-events-none z-20',
          isLoaded && imageLoaded ? 'opacity-100' : 'opacity-0'
        )}
        style={{
          width: boxSize,
          height: boxSize,
          transform: 'translate3d(var(--mouse-x), var(--mouse-y), 0)',
          willChange: 'transform',
        }}
      >
        <div
          className="absolute inset-0"
          style={{
            transform: 'translate3d(calc(var(--mouse-x) * -1), calc(var(--mouse-y) * -1), 0)',
            width: '100vw',
            height: '100vh',
            willChange: 'transform',
          }}
        >
          <img
            src={heroConfig.backgroundImage}
            alt="Hero Sharp"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Square border frame */}
      <div
        className={cn(
          'absolute top-0 left-0 pointer-events-none z-20',
          isLoaded && imageLoaded ? 'opacity-100' : 'opacity-0'
        )}
        style={{
          width: boxSize,
          height: boxSize,
          border: '1px solid rgba(255,255,255,0.4)',
          transform: 'translate3d(var(--mouse-x), var(--mouse-y), 0)',
          willChange: 'transform',
        }}
      >
        {/* Crosshair */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-4 h-px bg-white/60" />
          <div className="absolute w-px h-4 bg-white/60" />
        </div>
      </div>

      {/* Role labels on sides */}
      {roles[0] && (
        <div
          className={cn(
            'absolute left-8 lg:left-16 top-1/3 -translate-y-1/2 z-30 transition-all duration-[1200ms] ease-out-quart',
            isLoaded ? 'opacity-100' : 'opacity-0'
          )}
          style={{ transitionDelay: '800ms' }}
        >
          <span className="text-xs font-geist-mono uppercase tracking-[0.3em] text-white/70">
            {roles[0]}
          </span>
        </div>
      )}
      {roles[1] && (
        <div
          className={cn(
            'absolute right-8 lg:right-16 top-1/3 -translate-y-1/2 z-30 transition-all duration-[1200ms] ease-out-quart',
            isLoaded ? 'opacity-100' : 'opacity-0'
          )}
          style={{ transitionDelay: '900ms' }}
        >
          <span className="text-xs font-geist-mono uppercase tracking-[0.3em] text-white/70">
            {roles[1]}
          </span>
        </div>
      )}

      {/* Content Container */}
      <div className="relative z-30 flex flex-col items-center justify-end min-h-screen px-6 lg:px-12 pointer-events-none">
        {/* Profile Info */}
        <div
          className={cn(
            'flex flex-col items-center text-center transition-all duration-[1200ms] ease-out-quart pb-4 md:pb-8',
            isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
          style={{ transitionDelay: '500ms' }}
        >
          {/* Profile Photo */}
          <div className="w-20 h-20 md:w-24 md:h-24 rounded-full border-2 border-white/40 overflow-hidden mb-4 bg-white/10 backdrop-blur-sm">
            <img
              src="/images/about-1.jpg"
              alt="Profile"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Tagline */}
          <p className="text-sm md:text-base text-white/80 mb-2 max-w-xl">
            {heroConfig.tagline[language]}
          </p>

          {/* Contact Info Row */}
          <div className="flex items-center gap-4 text-white/60 text-xs md:text-sm mb-4">
            <span className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              Beijing, China
            </span>
            <span className="flex items-center gap-1">
              <Mail className="w-3 h-3" />
              atib@buaa.edu.cn
            </span>
            <span className="flex items-center gap-1">
              <GraduationCap className="w-3 h-3" />
              BUAA
            </span>
          </div>

          {/* Badges */}
          <div className="flex flex-wrap justify-center gap-2 mb-6 pointer-events-auto">
            {heroConfig.badges.map((badge, i) => (
              <span
                key={i}
                className="px-3 py-1.5 bg-white/10 backdrop-blur-sm rounded-full text-xs text-white/90 border border-white/20 hover:bg-white/20 transition-colors cursor-default"
              >
                {badge.icon} {badge.text[language]}
              </span>
            ))}
          </div>
        </div>

        {/* Main Heading - large and impactful */}
        <div
          className={cn(
            'text-center transition-all duration-[1200ms] ease-out-quart pb-8 md:pb-12',
            isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
          style={{ transitionDelay: '600ms' }}
        >
          <h1 className="text-[clamp(3rem,12vw,12rem)] font-black text-white tracking-[-0.04em] leading-[0.85]">
            {name}
          </h1>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-neutral-900/50 to-transparent z-20 pointer-events-none" />
    </section>
  );
}
